

module.exports = {
    googleClientID:"193971426124-jggiibuf23lmn2cm35v08qstkk57idtl.apps.googleusercontent.com",
    googleClientSecret:"OwhoruSLPgWiho-S5gw3f13t",
    mongoURI:"mongodb://Benjmhart:Radio123@ds117719.mlab.com:17719/emaily-dev-bhart",
    cookieKey: "fdsklfdskjhdfshdfui89efnkjfwel33k"
}