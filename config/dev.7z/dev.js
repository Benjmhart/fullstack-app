

module.exports = {
    googleClientID:"193971426124-jggiibuf23lmn2cm35v08qstkk57idtl.apps.googleusercontent.com",
    googleClientSecret:"OwhoruSLPgWiho-S5gw3f13t",
    mongoURI:"mongodb://Benjmhart:Radio123@ds117719.mlab.com:17719/emaily-dev-bhart",
    cookieKey: "fdsklfdskjhdfshdfui89efnkjfwel33k",
    stripePublishableKey:"pk_test_55AJgvitBJrD9eTlOgJY4LE5",
    stripeSecretKey:"sk_test_OKIwIO4WDSBKA02RIX8UudbS",
    sendGridKey:"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",
    redirectDomain:"http://localhost:3000"
}